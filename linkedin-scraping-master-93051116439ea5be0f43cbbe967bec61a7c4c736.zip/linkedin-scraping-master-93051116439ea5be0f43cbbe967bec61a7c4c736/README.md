# LinkedIn ad platform scraping

## Requirements
* Python 3
* Selenium, [geckodriver](https://github.com/mozilla/geckodriver)
* [requests](http://docs.python-requests.org/en/master/)
* [progressbar](https://pypi.python.org/pypi/progressbar2/3.34.3)
* LinkedIn dummy account

## Execution
* Adjust the settings from source/config.json
* Run source/main.py from the command line

## Usage
The script will launch a browser and ask for user's credentials. Once the login
is complete, the browser will close and the cookies will be passed to persistent
requests.Session object. The progressbar will show information such as number
of requests made and ETA. Any errors and failed fetches will also be printed
to the console. If backups are enabled, the collected data can be inspected from
there while the process is still running.

## Config.json
The most important adjustments to the execution can be done by altering the
config.json file. Here are brief explanations for the different fields.

* append (bool) : if true, data is appended to the file instead of potentially
overwriting.

* skip (int) : how many data items are skipped from start.

* first_id (int) : the query id of the first item. No need to change this.

* max_wait (in seconds) : maximum wait between get requests

* min_wait (in seconds) : minimum wait between get requests. The program will
start by waiting this amount of seconds. Every time a data fetch fails, waiting
is doubled until it hits "max_wait". Every successful fetch in turn halves the wait
until "min_wait" is reached again.

* request_timeout (in seconds) : how many seconds to wait for the response.

* cookies : set "enabled" to true in order to download old cookies from "path".
Useful when testing, so that one can avoid waiting for the browser and entering
credentials.

* backup : when enabled, a copy of the on-going data collection is created every
"freq" items, and saved to "path". It is mainly to protect from data corruptions
and unexpected errors, but it's also useful for inspecting the already collected
data while the code is still running.

* output_path : where to save the collected data

* parameters : a list of categories to include in the collection
  * id : field name in the query
  * title : column title
  * enabled : true or false, indicating whether to use this or not
  * path : where to find the mapping definitions
  * star : true or false, indicating whether "ALL" wildcard is included.

## Continuing an interrupted data collection

## Recovering specific data items that failed to come through

## Caveats
* Automatic file renaming is not yet implemented, so it is easy to accidentally
overwrite existing data. Data appending is enabled by default from options in which case
overwrites can't happen, but the output filename still has to be changed from
config.json before each run to avoid any hassle.

* The way LinkedIn encodes the query target strings might be volatile.
They previously (end of 2017) encoded '*' characters, but they did not encode ','
characters. As of January 2018, they seem to do the exact opposite. This code encodes
neither, which works, and most likely does not have to be changed. Still, it is worth
checking that the collected data is in line with the data fetched manually with the
site's tool.
