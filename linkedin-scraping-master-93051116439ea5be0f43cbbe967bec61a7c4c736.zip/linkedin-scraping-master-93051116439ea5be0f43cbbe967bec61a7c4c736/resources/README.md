This directory mainly contains files that define mappings between feature
names and query values. For example, the query value of 'accounting' is '47'.

## Adding new mappings
* Use csv format
* Two columns, one row for each mapping
* 1st col: query value, 2nd col: name
* New files must also be defined in source/config.json before they can be used.

## Some sources for mappings
* https://developer.linkedin.com/docs
* https://www.linkedin.com/ta/geo?query=
* https://www.linkedin.com/ta/industry?query=
* https://www.linkedin.com/ta/degree?query=
* https://www.linkedin.com/ta/fieldofstudy?query=
* https://www.linkedin.com/ta/skill?query=
