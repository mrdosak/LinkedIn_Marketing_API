from selenium import webdriver
from urllib import parse
from settings import Settings
from requests import Session
from getpass import getpass
import csv
import time
import pickle
import json
import progressbar
import os


# Function for authentication.
def auth():
    print("Launching browser...")
    driver = webdriver.Firefox()
    driver.get("https://www.linkedin.com")

    # Ask user to enter the credentials.
    email = input("Type in your LinkedIn email: ")
    password = getpass("Type in your LinkedIn password: ")

    # Pass the credentials with Selenium and log in.
    driver.find_element_by_id("login-email").send_keys(email)
    driver.find_element_by_id("login-password").send_keys(password)
    driver.find_element_by_id("login-submit").click()

    # Save the cookies and close the webdriver.
    cookies = driver.get_cookies()
    driver.close()
    return cookies


# Function for constructing the desired URL.
# Input: dictionary 'params', which contains the key-value pairs of the query.
# Output: encoded URL.
def getUrl(params):
    base  = "https://www.linkedin.com/ad/api/members/count?target="
    query = parse.urlencode(params, safe=',*')
    url   = base + parse.quote(query, safe=',*')
    return url


# Function for fetching the audience size with GET request.
# Input: session object, URL, query id, request timeout in seconds.
# Output: audience size, or -1 if the fetch failed.
def fetch(session, url, id, t):
    try:
        response = session.get(url, timeout=t) # GET request
        response.raise_for_status()            # check for success
        data = response.json()                 # response will be in json format
        count = data['count']
        return count
    except Exception as err:
        print("Failed to fetch data (id: ", id, "). ", err, sep='')
        return -1


# Function for writing single data instance.
# Input: data features and csv writer.
# Output: true if succeeded, false otherwise
def store(id, count, params, url, writer):
    try:
        data = [id, count]
        data.extend(params)
        data.extend([url, timeNow()])
        writer.writerow(data)
        return True
    except Exception as err:
        print("Failed to write data (id: ", id, "). ", err, sep='')
        return False


# Function for creating backups.
def createBackup(path, source, reader):
    try:
        with open(path, 'w', newline='', encoding='utf8') as backup:
            writer = csv.writer(backup)
            source.seek(0)
            for row in reader:
                writer.writerow(row)
            print("Backup created.")
    except Exception as err:
        print("Backup creation failed. ", err, sep='')


# Function for storing some useful data about the data.
# JSON format. 
def createMetadata(start, end, path, mode, count, firstId, lastId, params, missedIds, missedUrls):
    dict = {}
    dict['creator']        = ""
    dict['start_date']     = start
    dict['end_date']       = end
    dict['data_path']      = path
    dict['access_mode']    = mode
    dict['instance_count'] = count
    dict['first_id']       = firstId
    dict['last_id']        = lastId
    dict['parameters']     = params
    dict['missed_ids']     = missedIds
    dict['missed_urls']    = missedUrls
    try:
        name, extension = os.path.splitext(path)
        filename = name + "_metadata_" + time.strftime("%d%m%Y%H%M%S") + ".json"
        with open(filename, 'w') as metadatafile:
            json.dump(dict, metadatafile, indent = 2)
        print("Created metadata in: " + filename)
    except Exception as err:
        print("Metadata creation failed. ", err, sep='')


# Small helper function that returns the current date and time as a string.
def timeNow():
    return time.strftime("%d.%m.%Y %H:%M:%S")


# Function for printing data collection stats.
def printReport(id, firstId, successes, data_size, skip):
    attempted = id - firstId - skip
    failed    = attempted - successes
    total     = data_size - skip
    print("Attempted to download {} out of {} instances: {} successful, {} failed".format(attempted, total, successes, failed))


# Function for updating the sleeping period between fetches.
# Each failed fetch doubles the waiting time up to a certain limit.
# Similarly, successful fetches bring the time down.
def updateWait(response, wait, min_wait, max_wait):
    newWait = wait
    if response >= 0:
        if wait > min_wait:
            newWait = max(min_wait, wait / 2)
            print("Decreased the sleeping period to {} seconds".format(newWait))
    elif wait < max_wait:
        newWait = min(max_wait, wait * 2)
        print("Increased the sleeping period to {} seconds".format(newWait))
    return newWait


def main():
    # Load settings
    s = Settings("config.json")

    # Load cookies from file, or authenticate using Selenium.
    if (s.cookies_enabled):
        print("Loading cookies from file...")
        cookies = pickle.load(open(s.cookies_path, "rb"))
    else:
        cookies = auth()
        pickle.dump(cookies, open(s.cookies_path, "wb"))

    # Create session object for storing cookies and making requests.
    session = Session()
    for c in cookies:
        session.cookies.set(c['name'], c['value'])

    successes   = 0   # number of successful data fetches
    lastId      = 0   # id of the last successful fetch
    missedIds   = []  # list of ids of the failed fetches
    missedUrls  = []  # list of urls of the failed fetches
    id          = s.first_id   # data/query identifier
    wait        = s.min_wait   # minimum sleeping period between fetches

    print("Initiating data collection...")

    # Progress information for tracking the state of the collection.
    widgets = [
        ' [', progressbar.Timer(), ']',
        ' [Requests: ', progressbar.Counter(),  ']',
        ' [Progress: ', progressbar.Percentage(), ']',
        ' [', progressbar.ETA(), ']',
    ]
    #bar = progressbar.ProgressBar(max_value=s.data_size-s.skip, redirect_stdout=True, widgets=widgets).start()
    bar = progressbar.ProgressBar(maxval=s.data_size-s.skip, widgets=widgets).start()
    
    mode = 'w+'
    if s.append:
        mode = 'a+'
    start_time = timeNow()
    try:
        with open(s.output_path, mode, newline='', encoding='utf8') as output:
            writer = csv.writer(output)
            reader = csv.reader(output)

            # If the file is fresh (no append), write the column titles
            if not s.append:
                writer.writerow(s.titles)

            # Loop through all parameter combinations
            for p in s.combinations:
                c = [e[0] for e in p]   # codes i.e. '47'
                v = [e[1] for e in p]   # values i.e. 'Accounting'
                # Track the query identifier. Skip this item if id <= settings.skip.
                id += 1
                if id <= s.skip:
                    continue

                params = dict(zip(s.param_types, c))   # parameters as dictionary
                params = { k : v for k, v in params.items() if v != '*' }
                url    = getUrl(params)
                count  = fetch(session, url, id, s.timeout)   # fetch data
            
                if count >= 0:
                    # If fetch succeeded, write the data down
                    success = store(id, count, v, url, writer)
                    if (success):
                        successes += 1
                        lastId = id
                        if s.backup_enabled and successes % s.backup_freq == 0:
                            createBackup(s.backup_path, output, reader)
                else:
                    missedIds.append(id)
                    missedUrls.append(url)

                # Sleep
                wait = updateWait(count, wait, s.min_wait, s.max_wait)
                time.sleep(wait)
                bar.update(id-s.first_id-s.skip)

        bar.finish()
        print("Data collection finished!")

    except KeyboardInterrupt:
        print("Data collection aborted by user.")
    finally:
        printReport(id, s.first_id, successes, s.data_size, s.skip)
        end_time = timeNow()
        createMetadata(start_time, end_time, s.output_path, mode, successes, s.first_id, lastId, s.param_types, missedIds, missedUrls)


if __name__ == '__main__':
    main()
