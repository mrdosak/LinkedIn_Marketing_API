from itertools import product
import json
import csv
import os

def getAbsPath(name):
    return os.path.join(os.path.dirname(__file__), name)

# Get the code-value mappings of parameters i.e. '47' -> 'Accounting'
def getMapping(path, addStar):
    dict = {}
    with open(path) as csvfile:
        reader = csv.reader(csvfile)
        if addStar:
            dict['*'] = '*'
        for row in reader:
            dict[row[0]] = row[1]
        return dict;

# Class for fetching and storing settings.
class Settings:
    def __init__(self, path):
        with open(getAbsPath(path)) as jsonfile:
            self.settings = json.load(jsonfile)

        self.append          = self.settings['append']
        self.skip            = self.settings['skip']
        self.first_id        = self.settings['first_id']
        self.cookies_enabled = self.settings['cookies']['enabled']
        self.cookies_path    = getAbsPath(self.settings['cookies']['path'])
        self.output_path     = getAbsPath(self.settings['output_path'])
        self.backup_path     = getAbsPath(self.settings['backup']['path'])
        self.backup_enabled  = self.settings['backup']['enabled']
        self.backup_freq     = self.settings['backup']['freq']
        self.timeout         = self.settings['request_timeout']
        self.min_wait        = self.settings['min_wait']
        self.max_wait        = self.settings['max_wait']
        self.param_types     = self.getParamTypes()
        self.titles          = self.getTitles()
        self.combinations, self.data_size = self.getCombinations()

    
    # Get the parameter types.
    def getParamTypes(self):
        params = []
        for p in self.settings['parameters']:
            if (p['enabled']):
                params.append(p['id'])
        return params


    # Titles, the data column names.
    def getTitles(self):
        titles = ["ID", "Audience size"]
        for p in self.settings['parameters']:
            if (p['enabled']):
                titles.append(p['title'])
        titles.extend(["URL", "Time"])
        return titles

    
    # Get all possible parameter combinations and the amount of them.
    def getCombinations(self):
        allParams = []
        data_size = 1
        for p in self.settings['parameters']:
            if (p['enabled']):
                path = getAbsPath(p['path'])
                params = getMapping(path, p['star']).items()
                allParams.append(params)
                data_size *= len(params)
        return (product(*allParams), data_size)
